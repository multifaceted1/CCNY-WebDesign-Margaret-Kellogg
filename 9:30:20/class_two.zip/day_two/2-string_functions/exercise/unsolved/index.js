/*

  Using the lyricString variable below and String Functions on that variable:
    1. Log the length of the string.
    2. Write an if else statement if the string value is greater than or equal to 50
    3. Find the first instance/index of a lowercase i
    4. Find the first instance of an uppercase I
    5. Log only the word top
    6. Log it all to uppercase
    7. Log it all to lowercase
    8. Get the value of the string at the 15th index
    9. Write an if else statement looking to see that the word "back" is contained in the string
    10. Write an if else statement looking to see that the word "back" is contained in the string

    Some Bonus:
    1. Log the word "slide" and change it to all toUpperCase
    2. Log the whole string with only the word "slide" all in uppercase
    3. Prompt a word and write an if else statement check if the word is in the string variable

*/

var lyricString = "When I get to the bottom I go back to the top of the slide";
